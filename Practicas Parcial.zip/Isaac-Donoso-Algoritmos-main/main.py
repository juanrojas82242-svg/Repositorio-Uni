print("algo")
print("algopene")
